#coding:utf-8

'''
    filename:superman.py
    create a class
'''



class SuperMan:
    '''
    A class of superman
    '''
    def __init__(self,name):
        self.name = name
        self.gender = 1 #1,male
        self.single = False
        self.illness = False
    def nine_negative_kungfu(self):
        return 'Ya! You have to die.'


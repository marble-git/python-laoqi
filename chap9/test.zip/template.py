#coding:utf-8

'''
    filename:
        chap:
    subject:
    conditions:
    solution:
'''






if __name__ == '__main__':
    pass


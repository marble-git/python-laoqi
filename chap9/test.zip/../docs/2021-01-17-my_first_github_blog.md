this is my first blog about learning  python.
use web [prose.io](htt://prose.io "prose.io") to post this blog.


Enter text in [Markdown](http://daringfireball.net/projects/markdown/). Use the toolbar above, or click the **?** button for formatting help.

#coding:utf-8

'''
    filename:test.py
'''

import collections


print('-'*60)
class M(type):
    @classmethod
    def __prepare__(metacls,name,base):
        print('Meta __prepare__ called')
        print('metacls :',metacls)
        return collections.OrderedDict()
    def __new__(metacls,name,base,attr):
        print('Meta __new__ called')
        print('metacls :',metacls)
        return type.__new__(metacls,name,base,attr)
    def __init__(self,name,base,attr):
        print('Meta __init__ called')
        print('self :',self)
        return type.__init__(self,name,base,attr)
    def __call__(self):
        print('Meta __call__ called')
        print('self :',self)
        ins = type.__call__(self)
        print('ins :',ins)
        print('Meta __call__ ending')
        return ins

print('-'*50)
class D(metaclass = M):
    def __init__(self):
        print('D __init__ called')
        print('self :',self)
        print('D __init__ ending')
    def __new__(self):
        print('D __new__ called')
        print('self :',self)
        print('D __new__ ending')
        return super().__new__(self)
print('-'*40)
d=D()
print('d :',d)
